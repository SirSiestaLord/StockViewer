using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
public class changer : MonoBehaviour
{
    public Clear Main =  new Clear();
    public GameObject Parent;
    public static List<string> Stoklar;

    public static List<string> GirisTarihler;
    public static List<string> Miktars;
    public static List<string> Stoksg;
    public static List<string> Birims;
    public static List<string> Ttss;
    public  List<GameObject> Changers;
    public  TextMeshProUGUI StoklarText;
    public  TextMeshProUGUI GirisTarihlerText;
    public  TextMeshProUGUI MiktarsText;
    public  TextMeshProUGUI Bos;
    public  TextMeshProUGUI StoksText;
    public  TextMeshProUGUI BirimsText;
    public  TextMeshProUGUI TtsText;

        private  TextMeshPro c1;
    private  TextMeshPro c2;
    private   TextMeshPro c3;
    private  TextMeshPro c4;
    private  TextMeshPro c5;
    private  TextMeshPro c6;
    // Start is called before the first frame update
    void Start()
    {
        Stoklar=Main.Stoklar;
        GirisTarihler=Main.GirisTarihler;
        Miktars=Main.Miktars;
        Stoksg=Main.Stoksg;
        Birims=Main.Birims;
        Ttss=Main.Ttss;

    }

    // Update is called once per frame
    void Update()
    {
        
    }
    void OnMouseDown()
    {        

        Parent=gameObject.transform.parent.gameObject;
        string bos=Bos.text;
        GameObject child1 = Parent.transform.GetChild(0).gameObject;

        GameObject child2 = Parent.transform.GetChild(1).gameObject;

        GameObject child3 = Parent.transform.GetChild(2).gameObject;

        GameObject child4 = Parent.transform.GetChild(3).gameObject;

        GameObject child5 = Parent.transform.GetChild(4).gameObject;

        GameObject child6 = Parent.transform.GetChild(5).gameObject;
          
        GameObject child7 = Parent.transform.GetChild(6).gameObject;
        
       
        c1=child1.GetComponent<TextMeshPro>();
        c2=child2.GetComponent<TextMeshPro>();
        c3=child3.GetComponent<TextMeshPro>();
        c4=child4.GetComponent<TextMeshPro>();
        c5=child5.GetComponent<TextMeshPro>();
        c6=child6.GetComponent<TextMeshPro>();
        Debug.Log(String.Format(c1.text));
         Debug.Log(String.Format(c2.text));
          Debug.Log(String.Format(c3.text));
           Debug.Log(String.Format(c4.text));
            Debug.Log(String.Format(c5.text));
         int indexc1 = Adder.Stoklar.IndexOf(c1.text);
         string a =c1.text.ToString();
        string b =c2.text.ToString();
         string c =c3.text.ToString();
        string d =c4.text.ToString();
            string e =c5.text.ToString();
        
        Stoklar[indexc1]=(StoklarText.text);
        GirisTarihler[indexc1]=(GirisTarihlerText.text);
        Miktars[indexc1]=(MiktarsText.text);
        Stoksg[indexc1]=(StoksText.text);
        Birims[indexc1]=(BirimsText.text);
        
        c1.SetText(StoklarText.text);
        c2.SetText(GirisTarihlerText.text);
        c3.SetText(MiktarsText.text);
        c4.SetText(StoksText.text);
        c5.SetText(BirimsText.text);
        if(c1.text==bos){Stoklar[indexc1]=(a); c1.SetText(a);}
        if(c2.text==bos){GirisTarihler[indexc1]=(b); c2.SetText(b);}//Sen Az Önce Programa Hiçliği Tanıdın -_- -Onu Da Yanlış
        if(c3.text==bos){Miktars[indexc1]=(c); c3.SetText(c);}
        if(c4.text==bos){Stoksg[indexc1]=(d); c4.SetText(d);}
        if(c5.text==bos){Birims[indexc1]=(e); c5.SetText(e);}
        int total=int.Parse((c3.text.Trim((char)8203)))*int.Parse((c4.text.Trim((char)8203)));
        TtsText.text=total.ToString();
        Ttss[indexc1]=(TtsText.text);
        c6.SetText(TtsText.text);
    }
}
