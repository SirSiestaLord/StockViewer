using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.Serialization;
public class WriteRead : MonoBehaviour
{

    public bool save;
    public bool load;
      public Clear Main =  new Clear();
            string stokpath = System.Environment.GetFolderPath(System.Environment.SpecialFolder.MyDocuments) + "/StockFiles/StockFileStockSave.json";
            string girispath = System.Environment.GetFolderPath(System.Environment.SpecialFolder.MyDocuments) + "/StockFiles/StockFileDateSave.json";
            string miktarpath = System.Environment.GetFolderPath(System.Environment.SpecialFolder.MyDocuments) + "/StockFiles/StockFileNumberSave.json";
            string Stoksgpath = System.Environment.GetFolderPath(System.Environment.SpecialFolder.MyDocuments) + "/StockFiles/StockFileStoksSave.json";
            string Birimspath = System.Environment.GetFolderPath(System.Environment.SpecialFolder.MyDocuments) + "/StockFiles/StockFileBSave.json";
            string Ttsspath = System.Environment.GetFolderPath(System.Environment.SpecialFolder.MyDocuments) + "/StockFiles/StockFileTSave.json";
            string BosReferans = System.Environment.GetFolderPath(System.Environment.SpecialFolder.MyDocuments) + "/StockFiles/BosReferans.json";
            string Lenght = System.Environment.GetFolderPath(System.Environment.SpecialFolder.MyDocuments) + "/StockFiles/StockFileLSave.json";
    public GameObject Parent;
    public  List<string> Stoklar;
    public  List<string> GirisTarihler;
    public  List<string> Miktars;
    public  List<string> Stoksg;
    public  List<string> Birims;
    public  List<string> Ttss;
    public  List<int> IntList;
    public  List<GameObject> Changers;
    public  TextMeshProUGUI StoklarText;
    public  TextMeshProUGUI GirisTarihlerText;
    public  TextMeshProUGUI MiktarsText;
    public  TextMeshProUGUI StoksText;
    public  TextMeshProUGUI BirimsText;
    public  TextMeshProUGUI TtsText;
     public GameObject Template;
    private  TextMeshPro c1;
    private  TextMeshPro c2;
    private   TextMeshPro c3;
    private  TextMeshPro c4;
    private  TextMeshPro c5;
    private  TextMeshPro c6;
    StreamWriter  Stokwriter;
     StreamWriter  Giriswriter;
     StreamWriter  Miktarswriter;
     StreamWriter  Stoksgwriter;

           StreamWriter  Birimswriter;
            StreamWriter  BosReferanswriter;
    public int last;
    StreamWriter  Ttsswriter;
     public int news;
         public static float a=Adder.a;

   /* public static float a=-(float)0.8;*/
     public string d;
   void Start()
   {
      
   }
     public static void DeleteDirectory(string directoryName, bool checkDirectiryExist)
        {
            if (Directory.Exists(directoryName))
                Directory.Delete(directoryName, true);
            else if (checkDirectiryExist)
                throw new SystemException("Directory you want to delete is not exist");
        }
    
  
   void OnMouseDown()
   {
        Stoklar=Main.Stoklar;
        GirisTarihler=Main.GirisTarihler;
        Miktars=Main.Miktars;
        Stoksg=Main.Stoksg;
        Birims=Main.Birims; 
        Ttss=Main.Ttss;
        string folder=System.Environment.GetFolderPath(System.Environment.SpecialFolder.MyDocuments) + "/StockFiles";
           
    if(save){
      
      /*try{Directory.Delete(folder,true);  
      Directory.CreateDirectory(folder);}
      catch(IOException exp){}*/
      DirectoryInfo yourRootDir = new DirectoryInfo(folder);
            foreach (DirectoryInfo dir in yourRootDir.GetDirectories())
                    DeleteDirectory(dir.FullName, true);
       /* File.Create(stokpath);
        File.Create(girispath);
        File.Create(miktarpath);
        File.Create(Stoksgpath);
        File.Create(Birimspath);
        File.Create(Ttsspath);
        File.Create(Lenght);*/


     
          /*Stokwriter.Equals(BosReferanswriter);
        Giriswriter.Equals(BosReferanswriter);
        Miktarswriter.Equals(BosReferanswriter);
        Stoksgwriter.Equals(BosReferanswriter);
        Birimswriter.Equals(BosReferanswriter);
        Ttsswriter.Equals(BosReferanswriter);*/
         Stokwriter = new StreamWriter(stokpath, false);
        Giriswriter = new StreamWriter(girispath, false);
        Miktarswriter = new StreamWriter(miktarpath, false);
        Stoksgwriter= new StreamWriter(Stoksgpath, false);
        Birimswriter = new StreamWriter(Birimspath, false);
        BosReferanswriter = new StreamWriter(BosReferans, false);
       Ttsswriter= new StreamWriter(Ttsspath, false);
        
      
          StreamWriter  Lenghtwriter = new StreamWriter(Lenght, false);
        Lenghtwriter.WriteLine(Stoklar.Count);
    

        for(int i=0;i<Ttss.Count;i++){
            
            Stokwriter.WriteLineAsync(Stoklar[i]);
            Giriswriter.WriteLineAsync(GirisTarihler[i]);
            Miktarswriter.WriteLineAsync(Miktars[i]);
            Stoksgwriter.WriteLineAsync(Stoksg[i]);
            Birimswriter.WriteLineAsync(Birims[i]);
            Ttsswriter.WriteLineAsync(Ttss[i]);
            
        }
        
        Giriswriter.Close();
        Miktarswriter.Close();
        Stoksgwriter.Close();
        Birimswriter.Close();
        Ttsswriter.Close();
        Stokwriter.Close();
        Lenghtwriter.Close();
        BosReferanswriter.Close();
        }
    
    else if(load){ 
            string stokpath = System.Environment.GetFolderPath(System.Environment.SpecialFolder.MyDocuments) + "/StockFiles/StockFileStockSave.json";
            string girispath = System.Environment.GetFolderPath(System.Environment.SpecialFolder.MyDocuments) + "/StockFiles/StockFileDateSave.json";
            string miktarpath = System.Environment.GetFolderPath(System.Environment.SpecialFolder.MyDocuments) + "/StockFiles/StockFileNumberSave.json";
            string Stoksgpath = System.Environment.GetFolderPath(System.Environment.SpecialFolder.MyDocuments) + "/StockFiles/StockFileStoksSave.json";
            string Birimspath = System.Environment.GetFolderPath(System.Environment.SpecialFolder.MyDocuments) + "/StockFiles/StockFileBSave.json";
            string Ttsspath = System.Environment.GetFolderPath(System.Environment.SpecialFolder.MyDocuments) + "/StockFiles/StockFileTSave.json";
            string Lenght = System.Environment.GetFolderPath(System.Environment.SpecialFolder.MyDocuments) + "/StockFiles/StockFileLSave.json";
        StreamReader  Stokread= new StreamReader(stokpath);
         StreamReader  Girisread= new StreamReader(girispath);
      StreamReader  Miktarsread = new StreamReader(miktarpath);
      StreamReader  Stoksgread = new StreamReader(Stoksgpath);
      StreamReader  Birimsread = new StreamReader(Birimspath);
      StreamReader  Ttssread = new StreamReader(Ttsspath);
      StreamReader  Lenghtread = new StreamReader(Lenght);
      int lenght = int.Parse(Lenghtread.ReadLine().Trim((char)8203)); 
for(int i=0;i<lenght;i++){
      
    GameObject duplicate = Instantiate(Template);
         duplicate.transform.position = new Vector3(duplicate.transform.position.x , Adder.a-(float)0.8, duplicate.transform.position.z);
          Main.Duplicates.Add((GameObject)duplicate);
          duplicate.SetActive(true);
       Stoklar.Add(Stokread.ReadLine());
       GirisTarihler.Add(Girisread.ReadLine());
       Miktars.Add(Miktarsread.ReadLine());
       Stoksg.Add(Stoksgread.ReadLine());
       Birims.Add(Birimsread.ReadLine());
        Ttss.Add(Ttssread.ReadLine());

             Adder.a=(float) Adder.a-(float)0.8;
        GameObject child1 = duplicate.transform.GetChild(0).gameObject;

        GameObject child2 = duplicate.transform.GetChild(1).gameObject;

        GameObject child3 = duplicate.transform.GetChild(2).gameObject;

        GameObject child4 = duplicate.transform.GetChild(3).gameObject;

        GameObject child5 = duplicate.transform.GetChild(4).gameObject;

        GameObject child6 = duplicate.transform.GetChild(5).gameObject;
          
        GameObject child7 = duplicate.transform.GetChild(6).gameObject;

        c1=child1.GetComponent<TextMeshPro>();
        c2=child2.GetComponent<TextMeshPro>();
        c3=child3.GetComponent<TextMeshPro>();
        c4=child4.GetComponent<TextMeshPro>();
        c5=child5.GetComponent<TextMeshPro>();
        c6=child6.GetComponent<TextMeshPro>();
        
        c1.SetText(Stoklar[i]);
        c2.SetText(GirisTarihler[i]);
        c3.SetText(Miktars[i]);
        c4.SetText(Stoksg[i]);
        c5.SetText(Birims[i]);
        c6.SetText(Ttss[i]);
    

  }    Stokread.Close();
        Girisread.Close();
        Miktarsread.Close();
        Stoksgread.Close();
        Birimsread.Close();
        Ttssread.Close();
        Lenghtread.Close();
}}}
