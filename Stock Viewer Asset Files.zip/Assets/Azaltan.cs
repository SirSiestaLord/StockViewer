using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
public class Azaltan : MonoBehaviour
{
        public static bool iscleared=false;

     public Clear Main =  new Clear();
    public Adder adder =  new Adder();
     public WriteRead wr =  new WriteRead();
    public GameObject Parent;
    public static List<string> Stoklar;
    public static List<string> GirisTarihler;
    public static List<string> Miktars;
    public static List<string> Stoksg;
    public static List<string> Birims;
    public static List<string> Ttss;
    public  List<int> IntList;
    public  List<GameObject> Changers;
    public  TextMeshProUGUI StoklarText;
    public  TextMeshProUGUI GirisTarihlerText;
    public  TextMeshProUGUI MiktarsText;
    public  TextMeshProUGUI StoksText;
    public  TextMeshProUGUI BirimsText;
    public  TextMeshProUGUI TtsText;
        public  TextMeshProUGUI Bos;

    private  TextMeshPro c1;
    private  TextMeshPro c2;
    private   TextMeshPro c3;
    private  TextMeshPro c4;
    private  TextMeshPro c5;
    private  TextMeshPro c6;
    public int last;
     public int news;
     public string d;
    // Start is called before the first frame update
    void Start()
    {
        Stoklar=Main.Stoklar;
        GirisTarihler=Main.GirisTarihler;
        Miktars=Main.Miktars;
        Stoksg=Main.Stoksg;
        Birims=Main.Birims;
        Ttss=Main.Ttss;
        Changers=adder.Changers;

    }

    // Update is called once per frame
    void Update()
    {
        
    }
    void OnMouseDown()
    {
       
        Parent=gameObject.transform.parent.gameObject;

        GameObject child1 = Parent.transform.GetChild(0).gameObject;

        GameObject child2 = Parent.transform.GetChild(1).gameObject;

        GameObject child3 = Parent.transform.GetChild(2).gameObject;

        GameObject child4 = Parent.transform.GetChild(3).gameObject;

        GameObject child5 = Parent.transform.GetChild(4).gameObject;

        GameObject child6 = Parent.transform.GetChild(5).gameObject;
          
        GameObject child7 = Parent.transform.GetChild(6).gameObject;
                string bos=Bos.text;

        c1=child1.GetComponent<TextMeshPro>();
        c2=child2.GetComponent<TextMeshPro>();
        c3=child3.GetComponent<TextMeshPro>();
        c4=child4.GetComponent<TextMeshPro>();
        c5=child5.GetComponent<TextMeshPro>();
        c6=child6.GetComponent<TextMeshPro>();
         d = System.DateTime.Now.ToString(@"dd");
         StreamWriter writer ;
        int indexc1 = Adder.Stoklar.IndexOf(c1.text);
        string a =c1.text.ToString();
        string b =c2.text.ToString();
        string c =c3.text.ToString();
        string de =c4.text.ToString();
        string e =c5.text.ToString();
       /* TtsText.text=total.ToString();
        Ttss[indexc1]=(TtsText.text);
        c6.SetText(TtsText.text);*/
        int indexc4 = Adder.Stoksg.IndexOf(c4.text);
        if(indexc4>0){Stoksg[indexc4]=(StoksText.text);}
        else{Stoksg.Add(StoksText.text);}

           int indexc3 = Adder.Stoksg.IndexOf(c3.text);
        /*if(indexc3>0){Miktars[indexc3]=(MiktarsText.text);}
        else{Miktars.Add(MiktarsText.text);}*/
        int a1=int.Parse(c4.text.Trim((char)8203)),
        a2=int.Parse(StoksText.text.Trim((char)8203)),
        a3=int.Parse(c3.text.Trim((char)8203));
        
        int sonuc=(a1-a2)*a3;
        sonuc=int.Parse(c6.text.Trim((char)8203))-sonuc;

         int sayidegeri=a1-a2;



       if(/*String.Compare(StoksText.text,c4.text) < 0 &&*/int.Parse(StoksText.text.Trim((char)8203))<int.Parse(c4.text.Trim((char)8203)))
            {
                    string path = "C:/Users/Tuğcan Çağlayan/Desktop" + "/Çıktı.txt";
                    /*if(d=="01"&&iscleared==false){    
                       writer = new StreamWriter(path, false);
                       iscleared=true;}
                    else
                    {*/
                       writer = new StreamWriter(path, true);
                  //  }
                    // AGA burası Çokomelli dikkatli ol 
                    writer.WriteLine(DateTime.Now.ToString("\n"+@"MM\/dd\/yyyy h\:mm tt")+" Tarihinde "+c1.text+" Stok Elemanı "+c4.text.Trim((char)8203)+" Miktarından "+StoksText.text.Trim((char)8203)+" Miktarına Düşürüldü.Elinizde "+sayidegeri.ToString()+" Miktarı kaldı ve sonucunda "+sonuc.ToString().Trim((char)8203)+" Tl kadar bir kazanç elde ettiniz.\n");
                    writer.Close();
                     c4.SetText(sayidegeri.ToString());
                     Adder.Stoksg[indexc4]=sayidegeri.ToString();
                     int total=int.Parse((c3.text.Trim((char)8203)))*int.Parse((c4.text.Trim((char)8203)));
                     c6.SetText(total.ToString());
                     Adder.Ttss[indexc4]=total.ToString();
                 
            }
        else if(String.Compare(StoksText.text,c4.text) == 0)
        {
                string path = "C:/Users/Tuğcan Çağlayan/Desktop" + "/Çıktı.txt";
                    if(d=="01"&&iscleared==false){    
                       writer = new StreamWriter(path, false);
                       iscleared=true;}
                    else
                    {
                       writer = new StreamWriter(path, true);
                    }

                    // AGA burası da Çokomelli dikkatli ol
                    writer.WriteLine(DateTime.Now.ToString("\n"+@"MM\/dd\/yyyy h\:mm tt")+" Tarihinde "+c1.text+" Stok Elemanı "+c4.text.Trim((char)8203)+" Miktarından "+StoksText.text.Trim((char)8203)+" Miktarına Düşürüldü.Elinizde "+sayidegeri.ToString()+" Miktarı kaldı ve sonucunda "+sonuc.ToString().Trim((char)8203)+" Tl kadar bir kazanç elde ettiniz.\n");
                    writer.Close();
    
                   c4.SetText(sayidegeri.ToString());
                     Adder.Stoksg[indexc4]=sayidegeri.ToString();
                     int total=int.Parse((c3.text.Trim((char)8203)))*int.Parse((c4.text.Trim((char)8203)));
                     c6.SetText(total.ToString());
                     Adder.Ttss[indexc4]=total.ToString();
            }
            else
                {
                }
    
    


       

    }
}
