using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ScrollController : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetAxis("Mouse ScrollWheel") > 0f) // forward
             {
                if(gameObject.transform.position.y>=(float)-0.34){}
                else{gameObject.transform.position = new Vector3(gameObject.transform.position.x , gameObject.transform.position.y+(float)0.5, gameObject.transform.position.z);}
                    

             }
        if (Input.GetAxis("Mouse ScrollWheel") < 0f) // backwards
        {
                gameObject.transform.position = new Vector3(gameObject.transform.position.x , gameObject.transform.position.y-(float)0.5, gameObject.transform.position.z);
            }
    }
}
