using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
public class Clear : MonoBehaviour
{
    public bool clear;
    public bool Toplam;
        public List<GameObject> Duplicates;
        public GameObject Addbutton;
        public string a;
         public  List<string> Stoklar;
        public  List<string> GirisTarihler;
        public  List<string> Miktars;
        public  List<string> Stoksg;
        public  List<string> Birims;
        public  List<string> Ttss;
        private GameObject Destroyable;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        Addbutton.GetComponent<Adder>();
        Adder.Duplicates=Duplicates;
        Adder.Stoklar=Stoklar;
        Adder.GirisTarihler=GirisTarihler;
        Adder.Miktars=Miktars;
        Adder.Stoksg=Stoksg;
        Adder.Birims=Birims;
        Adder.Ttss=Ttss;

    }

     void OnMouseDown()
    {
        if(clear){
        for(int i =0;i<Duplicates.Count;i++){
            Destroy(Duplicates[i]);
    
        }
        Adder.Duplicates.Clear();
                Adder.Stoklar.Clear();
        Adder.GirisTarihler.Clear();
        Adder.Miktars.Clear();
        Adder.Stoksg.Clear();
        Adder.Birims.Clear();
        Adder.Ttss.Clear();
        Adder.a=(float)0;
        }
        

    }
}
