using System.Net.Mime;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
public class Adder : MonoBehaviour
{   
    public GameObject Template;
         public GameObject TextTemplateCanvas;

    public static float a;
    public static List<GameObject> Duplicates;
    public static List<string> Stoklar;
    public static List<string> GirisTarihler;
    public static List<string> Miktars;
    public static List<string> Stoksg;
    public static List<string> Birims;
    public static List<string> Ttss;
    
     public  List<GameObject> Changers;

    public  TextMeshProUGUI StoklarText;
    public  TextMeshProUGUI GirisTarihlerText;
    public  TextMeshProUGUI MiktarsText;
    public  TextMeshProUGUI StoksText;
    public  TextMeshProUGUI BirimsText;
    public  TextMeshProUGUI TtsText;
     private  TextMeshPro c1;
    private  TextMeshPro c2;
    private   TextMeshPro c3;
    private  TextMeshPro c4;
    private  TextMeshPro c5;
    private  TextMeshPro c6;
    // Start is called before the first frame update
    void Start()
    {
         float a=(float)-1;
              }


    // Update is called once per frame
    void Update()
    {
       
    }
    void OnMouseDown()
    {
    
        
        int total=int.Parse((MiktarsText.text.Trim((char)8203)))*int.Parse((StoksText.text.Trim((char)8203)));
        Stoklar.Add(StoklarText.text);
        GirisTarihler.Add(GirisTarihlerText.text);
        Miktars.Add(MiktarsText.text);
        Stoksg.Add(StoksText.text);
        Birims.Add(BirimsText.text);
        Ttss.Add(total.ToString());
          

        GameObject duplicate = Instantiate(Template);
        duplicate.SetActive(true);
        duplicate.transform.position = new Vector3(duplicate.transform.position.x , a+(float)-0.8, duplicate.transform.position.z);
       
          Duplicates.Add((GameObject)duplicate);
           a=(float)a-(float)0.8;

        GameObject child1 = duplicate.transform.GetChild(0).gameObject;

        GameObject child2 = duplicate.transform.GetChild(1).gameObject;

        GameObject child3 = duplicate.transform.GetChild(2).gameObject;

        GameObject child4 = duplicate.transform.GetChild(3).gameObject;

        GameObject child5 = duplicate.transform.GetChild(4).gameObject;

        GameObject child6 = duplicate.transform.GetChild(5).gameObject;
          
        GameObject child7 = duplicate.transform.GetChild(6).gameObject;

          Changers.Add(duplicate.transform.GetChild(6).gameObject);

        c1=child1.GetComponent<TextMeshPro>();
        c2=child2.GetComponent<TextMeshPro>();
        c3=child3.GetComponent<TextMeshPro>();
        c4=child4.GetComponent<TextMeshPro>();
        c5=child5.GetComponent<TextMeshPro>();
        c6=child6.GetComponent<TextMeshPro>();
        c1.SetText(StoklarText.text);
        c2.SetText(GirisTarihlerText.text);
        c3.SetText(MiktarsText.text);
        c4.SetText(StoksText.text);
        c5.SetText(BirimsText.text);
        c6.SetText(total.ToString());

     

                     

    }
}
